# +-------------------------------------------------------------------------------------+
# |                                                                                     |
# |                         a&a (light) script v0.04.00 Beta 1                          |
# |                                                                                     |
# +-------------------------------------------------------------------------------------+
# |                                                                                     |
# |             Creative Commons Copyright 2002-2009 by UniversaliA aka aqwzsx          |
# |                               https://pinoychat.fun/botcommands.php                                   |
# |                                                                                     |
# +-------------------------------------------------------------------------------------+
# |                                                                                     |
# |        Website             @  https://pinoychat.fun/botcommands.php                                   |
# |        Forum & support     @  https://pinoychat.fun/botcommands.php                             |
# |        Features & bugs     @  https://pinoychat.fun/botcommands.php                              |
# |                                                                                     |
# +-------------------------------------------------------------------------------------+
# |                                                                                     |
# |                    #a&a & #botlending @ Undernet/Quakenet IRC                       |
# |                                                                                     |
# +-------------------------------------------------------------------------------------+
############ Command Binds ###########################

a:command -add deauth    pub:deauth    1003 501 Q

############ Command Procs ###########################

proc pub:deauth {hand chan args x mix} {

	chattr $hand -Q
	a:tell $x 11; return "..."
}

return "global Q commands"