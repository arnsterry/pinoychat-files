#########################################################################
##          BlackTools - The Ultimate Channel Control Script           ##
##                    One TCL. One smart Eggdrop                       ##
#########################################################################
############################   AUTH TCL   ###############################
#########################################################################
##                                                                     ##
##   a&a-style login suite for BlackTools:                            ##
##     .auth <password> [handle]   - log in; "handle" only needed if  ##
##                                   your current host isn't already  ##
##                                   recognized (advanced auth)        ##
##     .userset permident on|off   - stay recognized from this host   ##
##                                   forever, instead of a timed       ##
##                                   session                           ##
##     .whois [handle]             - show a user's auth/status info   ##
##                                                                     ##
##   HOW IT WORKS                                                     ##
##   BlackTools' commands (like every other BlackTools module) rely   ##
##   on eggdrop's own core matching: it only knows who you are if     ##
##   your CURRENT nick!ident@host matches a mask saved on your user   ##
##   record. This module makes ".auth" add that mask for you, so      ##
##   every existing BlackTools command recognizes you immediately -   ##
##   no per-command changes needed anywhere else in the script.       ##
##                                                                     ##
##   Unless you turn permident ON, a mask added by "auth" is only     ##
##   temporary: it auto-expires after auth:sessionlen minutes, just   ##
##   like a real login session, and you'll need to .auth again.       ##
##   With permident ON, that mask is kept for good.                   ##
##                                                                     ##
#########################################################################

# ---- settings ---------------------------------------------------------
# How many hosts to keep on a user record. Oldest is dropped once the
# limit is hit so people who roam a lot don't pile up dozens of masks.
set black(auth:maxhosts) 3

# How long (in minutes) a mask added by ".auth" stays valid before it's
# auto-removed, UNLESS the user has turned permident on.
set black(auth:sessionlen) 60

# ---- colour helpers -----------------------------------------------------
# mIRC control codes: \002 bold, \003NN colour, \017 reset.
proc black:col {fg text} { return "\003$fg$text\017" }
proc black:bold {text}   { return "\002$text\002" }

# ------------------------------------------------------------------------
# Follow-up hint after "pass" - BlackTools' own catch-all handler is what
# actually sets the password (via its msgm wildcard listener, which fires
# BEFORE plain msg binds like this one) - this just appends the a&a-style
# "here's how to log in from now on" guidance right after.
# ------------------------------------------------------------------------
bind msg -|- pass blacktools:auth:passhint

proc blacktools:auth:passhint {nick uhost hand text} {
	global botnick

	if {$hand == "" || $hand == "*" || ![validuser $hand]} { return }
	set newpass [lindex $text 0]
	if {$newpass == ""} { return }

	putserv "PRIVMSG $nick :Info regarding your account >>> user: [black:bold [black:col 03 $hand]], password: [black:bold [black:col 03 $newpass]]"
	putserv "PRIVMSG $nick :To authorise, type: \002/msg $botnick auth <your password>\002"
	putserv "PRIVMSG $nick :This is the first time you authorise; you can authorise from any host & nick using the advanced form: \002/msg $botnick auth $newpass $hand\002"
	putserv "PRIVMSG $nick :For permanent authorisation use \002/msg $botnick userset permident on\002 - this lets you give commands from this host without re-authorising."
}

# ------------------------------------------------------------------------
# .auth <password> [handle]        (msg only)
#
#   .auth <password>            - use this if your CURRENT host is
#                                  already recognized as some handle
#                                  (eggdrop passes that in as $hand)
#   .auth <password> <handle>   - "advanced" auth: works from ANY host,
#                                  any nick, as long as the password for
#                                  <handle> matches.
# ------------------------------------------------------------------------
bind msg -|- auth blacktools:msg:auth

proc blacktools:msg:auth {nick uhost hand text} {
	global black botnick

	set pass   [lindex $text 0]
	set target [lindex $text 1]

	if {$target == ""} {
		if {$hand != "" && $hand != "*" && [validuser $hand]} {
			set target $hand
		} else {
			# silent: unrecognized host, no handle (anti-spam)
			return
		}
	}

	if {$pass == ""} {
		putserv "PRIVMSG $nick :Usage: /msg $botnick auth <password> \[handle\]"
		return
	}

	if {![validuser $target]} {
		putserv "PRIVMSG $nick :[black:col 04 "No such user \"$target\"."]"
		return
	}

	# Basic brute-force throttle: 3 tries per minute per nick!host
	set key "authfail,[string tolower $uhost]"
	if {[info exists black($key)] && [lindex $black($key) 0] >= 3
	    && [unixtime] - [lindex $black($key) 1] < 60} {
		putserv "PRIVMSG $nick :[black:col 04 "Too many failed attempts. Try again in a minute."]"
		return
	}

	if {![passwdok $target $pass]} {
		if {[info exists black($key)] && [unixtime] - [lindex $black($key) 1] < 60} {
			set black($key) [list [expr {[lindex $black($key) 0] + 1}] [unixtime]]
		} else {
			set black($key) [list 1 [unixtime]]
		}
		putserv "PRIVMSG $nick :[black:col 04 "Invalid password."]"
		putlog "BT.Auth: failed login attempt for $target from $nick!$uhost"
		return
	}
	catch {unset black($key)}

	# Grab the PREVIOUS login info before we overwrite it, so we can show it
	set prevauth ""
	catch {set prevauth [getuser $target XTRA _LASTAUTH]}

	set permident 0
	catch {set permident [getuser $target XTRA _PERMIDENT]}

	# Build the mask for wherever this person is connecting from *right now*
	set ident [lindex [split $uhost "@"] 0]
	set host  [lindex [split $uhost "@"] 1]
	set newmask "*!$ident@$host"

	set hosts [getuser $target HOSTS]
	set firsttime [expr {[llength $hosts] == 0}]
	set alreadyknown [expr {[lsearch -nocase $hosts $newmask] != -1}]

	if {!$alreadyknown} {
		setuser $target HOSTS $newmask
		set hosts [getuser $target HOSTS]
		# Keep the list from growing forever - setuser HOSTS only ever
		# ADD a mask, so trimming has to go through delhost explicitly.
		while {[llength $hosts] > $black(auth:maxhosts)} {
			delhost $target [lindex $hosts 0]
			set hosts [getuser $target HOSTS]
		}

		# Unless permident is on, this mask is only a temporary session -
		# schedule it to be dropped again after auth:sessionlen minutes.
		if {$permident != "1"} {
			timer $black(auth:sessionlen) [list blacktools:auth:expiremask $target $newmask]
		}
	}

	setuser $target XTRA _LASTAUTH "[unixtime] $nick!$uhost"

	if {$firsttime} {
		putserv "PRIVMSG $nick :[black:bold [black:col 09 "Authorization successful"]] as [black:bold [black:col 03 $target]]."
		putserv "PRIVMSG $nick :This is your first login. From now on \002/msg $botnick auth <password>\002 works automatically while you're on this host."
		putserv "PRIVMSG $nick :If you change host/vhost/cloak later, use the advanced form: \002/msg $botnick auth <password> $target\002 - it works from anywhere."
		putserv "PRIVMSG $nick :Want to stay recognized on this host permanently (no re-auth, no expiry)? \002/msg $botnick userset permident on\002"
	} else {
		set lastline "this is your first recorded login"
		if {$prevauth != ""} {
			set prevtime [lindex $prevauth 0]
			set prevwho  [lindex $prevauth 1]
			if {[catch {clock format $prevtime -format "%a %b %d %H:%M:%S %Y"} prevtimestr]} {
				set prevtimestr $prevtime
			}
			set lastline "last logged in as [black:col 03 $target] from [black:col 12 $prevwho] on $prevtimestr"
		}
		putserv "PRIVMSG $nick :[black:bold [black:col 09 "Authorization successful"]] as [black:bold [black:col 03 $target]], $lastline."
	}

	putlog "BT.Auth: $target successfully authed from $nick!$uhost"
}

# Called by the session timer to drop a temporary auth mask, unless the
# user has since turned permident on.
proc blacktools:auth:expiremask {target mask} {
	if {![validuser $target]} { return }
	set permident 0
	catch {set permident [getuser $target XTRA _PERMIDENT]}
	if {$permident == "1"} { return }
	catch {delhost $target $mask}
	putlog "BT.Auth: session expired for $target, removed temporary mask $mask"
}

# ------------------------------------------------------------------------
# .userset permident on|off        (msg only, must be currently recognized)
# ------------------------------------------------------------------------
bind msg -|- userset blacktools:msg:userset

proc blacktools:msg:userset {nick uhost hand text} {
	global botnick

	if {$hand == "" || $hand == "*" || ![validuser $hand]} {
		putserv "PRIVMSG $nick :[black:col 04 "FAILED: you are not authenticated, type: /msg $botnick auth <password> <handle>"]"
		return
	}

	set setting [string tolower [lindex $text 0]]
	set value   [string tolower [lindex $text 1]]

	if {$setting != "permident" || ($value != "on" && $value != "off")} {
		putserv "PRIVMSG $nick :Usage: /msg $botnick userset permident <on|off>"
		return
	}

	if {$value == "on"} {
		setuser $hand XTRA _PERMIDENT 1
		putserv "PRIVMSG $nick :[black:col 03 "permident is now ON"] - your current hostmask will be kept permanently, no more re-auth needed from this host."
	} else {
		setuser $hand XTRA _PERMIDENT 0
		putserv "PRIVMSG $nick :[black:col 07 "permident is now OFF"] - masks added by auth will expire again after the normal session length."
	}
	putlog "BT.Auth: $hand set permident $value"
}

# ------------------------------------------------------------------------
# .whois [handle]        (msg only) - defaults to yourself
# ------------------------------------------------------------------------
bind msg -|- whois blacktools:msg:whois

proc blacktools:msg:whois {nick uhost hand text} {
	global botnick

	if {$hand == "" || $hand == "*" || ![validuser $hand]} {
		putserv "PRIVMSG $nick :[black:col 04 "FAILED: you are not authenticated, type: /msg $botnick auth <password> <handle>"]"
		return
	}

	set target [lindex $text 0]
	if {$target == ""} {
		set target $hand
	}

	if {![validuser $target]} {
		putserv "PRIVMSG $nick :[black:col 04 "No such user \"$target\"."]"
		return
	}

	set flags     [chattr $target]
	set hosts     [getuser $target HOSTS]
	set permident 0
	catch {set permident [getuser $target XTRA _PERMIDENT]}
	set prevauth  ""
	catch {set prevauth [getuser $target XTRA _LASTAUTH]}

	# eggdrop already resolved $hand from this connection's current
	# hostmask - "authenticated right now" just means it matches $target.
	set authednow [expr {($hand != "" && $hand == $target) ? "YES" : "NO"}]

	set permstr [expr {$permident == "1" ? "[black:col 03 ON]" : "[black:col 07 OFF]"}]
	set authstr [expr {$authednow == "YES" ? "[black:col 03 YES]" : "[black:col 04 NO]"}]

	putserv "PRIVMSG $nick :handle: [black:bold [black:col 03 $target]], flags: [black:col 12 $flags], permident: $permstr, authenticated (this connection): $authstr"
	putserv "PRIVMSG $nick :hostmasks: [black:col 12 [join $hosts ", "]]"

	if {$prevauth != ""} {
		set prevtime [lindex $prevauth 0]
		set prevwho  [lindex $prevauth 1]
		if {[catch {clock format $prevtime -format "%a %b %d %H:%M:%S %Y"} prevtimestr]} {
			set prevtimestr $prevtime
		}
		putserv "PRIVMSG $nick :last auth: [black:col 12 $prevwho] on $prevtimestr"
	} else {
		putserv "PRIVMSG $nick :last auth: never"
	}
}
